# Chibani TV — Google TV

Application Android TV / Google TV (Kotlin, Jetpack Compose for TV, Media3 ExoPlayer).

## Ce que fait l'app
- Colonne de gauche : 22 pays arabes (Maghreb en tête), « Toutes (langue arabe) », « Mes favoris », « Ma playlist M3U ».
- Grille des chaînes avec logos, lecture plein écran HLS/MPEG-TS.
- Zapping : CH+/CH- ou haut/bas (quand le menu est masqué). OK = menu, Retour = liste.
- Appui long sur une chaîne = ajouter/retirer des favoris.
- « Ma playlist M3U » : URL d'un abonnement IPTV légal (enregistrée sur la TV).

## Source des chaînes
Playlists publiques du projet open source **iptv-org** (chaînes en diffusion libre) :
`https://iptv-org.github.io/iptv/countries/<code>.m3u` et `languages/ara.m3u`.
Listes communautaires : certains flux peuvent être hors ligne ou géo-bloqués
(le lecteur l'indique, il suffit de zapper).

## Compiler
1. Ouvrir le dossier dans **Android Studio** (Koala ou plus récent) et laisser la synchro Gradle se faire.
2. *Build > Build APK(s)* → `app/build/outputs/apk/debug/app-debug.apk`.

## Installer sur la Google TV
- TV : *Paramètres > Système > À propos* → cliquer 7× sur « Build Android TV OS » (mode développeur),
  puis activer le débogage ADB.
- PC : `adb connect <IP_DE_LA_TV>` puis `adb install app-debug.apk`.
- Sans PC : app **Send Files to TV** ou **Downloader**.

## Pistes d'évolution
Guide des programmes (EPG XMLTV), recherche vocale, tri par catégorie (`group-title`),
détection automatique des flux morts.
