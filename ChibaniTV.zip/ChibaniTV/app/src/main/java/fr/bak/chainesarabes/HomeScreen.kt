package fr.bak.chainesarabes

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.tv.material3.*
import coil.compose.AsyncImage
import fr.bak.chainesarabes.data.Channel
import fr.bak.chainesarabes.data.Source
import fr.bak.chainesarabes.data.Sources

private val Sand = Color(0xFFF2E8CF)
private val Muted = Color(0xFF9DB3A9)
private val Panel = Color(0xFF16201C)

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun HomeScreen(vm: HomeViewModel, onPlay: (List<Channel>, Int) -> Unit) {
    val state by vm.state.collectAsState()
    var showDialog by remember { mutableStateOf(false) }

    Row(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0B1512))
            .padding(horizontal = 32.dp, vertical = 24.dp)
    ) {
        // ----- Colonne des pays -----
        LazyColumn(
            modifier = Modifier.width(270.dp).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            item {
                Text(
                    "Chibani TV",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Sand,
                    modifier = Modifier.padding(start = 12.dp, bottom = 16.dp),
                )
            }
            items(Sources.all, key = { it.id }) { src ->
                ListItem(
                    selected = src == state.selected,
                    onClick = { if (src == Source.Custom) showDialog = true else vm.select(src) },
                    headlineContent = {
                        Text(src.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    },
                    leadingContent = { Text(src.emoji, fontSize = 20.sp) },
                )
            }
        }

        Spacer(Modifier.width(32.dp))

        // ----- Grille des chaînes -----
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Text(
                "${state.selected.emoji}  ${state.selected.label}",
                style = MaterialTheme.typography.headlineMedium,
                color = Sand,
            )
            Text(
                when {
                    state.loading -> "Chargement de la liste…"
                    state.error != null -> "La liste n’a pas pu être chargée"
                    else -> "${state.channels.size} chaînes — appui long sur une chaîne pour l’ajouter aux favoris"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = Muted,
                modifier = Modifier.padding(top = 4.dp, bottom = 20.dp),
            )

            when {
                state.loading -> Unit
                state.error != null -> Message(state.error!!)
                state.channels.isEmpty() -> Message(
                    if (state.selected == Source.Favorites)
                        "Aucun favori pour l’instant. Fais un appui long sur une chaîne pour l’ajouter ici."
                    else "Aucune chaîne disponible pour ce pays."
                )
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(180.dp),
                    contentPadding = PaddingValues(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                ) {
                    itemsIndexed(state.channels, key = { _, c -> c.url }) { i, ch ->
                        ChannelCard(
                            ch = ch,
                            isFavorite = ch.url in state.favoriteUrls,
                            onClick = { onPlay(state.channels, i) },
                            onLongClick = { vm.toggleFavorite(ch) },
                        )
                    }
                }
            }
        }
    }

    if (showDialog) {
        PlaylistDialog(
            initial = vm.customUrl ?: "",
            onDismiss = { showDialog = false },
            onSave = { showDialog = false; vm.setCustomUrl(it) },
        )
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun Message(text: String) {
    Text(text, color = Muted, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.widthIn(max = 560.dp))
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun ChannelCard(ch: Channel, isFavorite: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    Card(onClick = onClick, onLongClick = onLongClick, modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Panel),
            contentAlignment = Alignment.Center,
        ) {
            if (ch.logo != null) {
                AsyncImage(
                    model = ch.logo,
                    contentDescription = ch.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(14.dp),
                )
            } else {
                Text(ch.name.take(2).uppercase(), style = MaterialTheme.typography.headlineMedium, color = Sand)
            }
            if (isFavorite) {
                Text("⭐", modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
        }
        Text(
            ch.name,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
        )
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun PlaylistDialog(initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    val valid = text.trim().startsWith("http")

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .width(600.dp)
                .background(Panel, RoundedCornerShape(16.dp))
                .padding(28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Ma playlist M3U", style = MaterialTheme.typography.titleLarge, color = Sand)
            Text(
                "Saisis l’adresse d’une playlist .m3u fournie par un service auquel tu es abonné légalement.",
                style = MaterialTheme.typography.bodyMedium,
                color = Muted,
            )
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
                cursorBrush = SolidColor(Sand),
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0B1512), RoundedCornerShape(8.dp))
                    .padding(14.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { onSave(text.trim()) }, enabled = valid) { Text("Charger la playlist") }
                OutlinedButton(onClick = onDismiss) { Text("Annuler") }
            }
        }
    }
}
