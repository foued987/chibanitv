package fr.bak.chainesarabes

import fr.bak.chainesarabes.data.Channel

/** Liste en cours de lecture, pour zapper avec haut/bas sur la télécommande. */
object PlaybackQueue {
    var channels: List<Channel> = emptyList()
    var index: Int = 0
    val current: Channel get() = channels[index]
}
