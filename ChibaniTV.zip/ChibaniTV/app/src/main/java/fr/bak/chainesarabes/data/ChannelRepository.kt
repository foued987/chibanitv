package fr.bak.chainesarabes.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Source des chaînes : playlists publiques du projet iptv-org
 * (chaînes en accès libre, classées par pays), + favoris + playlist perso.
 */
class ChannelRepository(context: Context) {

    private val prefs = context.getSharedPreferences("chaines_prefs", Context.MODE_PRIVATE)
    private val cache = ConcurrentHashMap<String, List<Channel>>()

    var customUrl: String?
        get() = prefs.getString(KEY_CUSTOM, null)
        set(value) = prefs.edit().putString(KEY_CUSTOM, value).apply()

    suspend fun load(source: Source): List<Channel> = when (source) {
        Source.Favorites -> favorites()
        Source.AllArabic -> fetch("$BASE/languages/ara.m3u")
        is Source.Country -> fetch("$BASE/countries/${source.code}.m3u")
        Source.Custom -> {
            val url = customUrl
                ?: throw IllegalStateException("Aucune playlist enregistrée. Sélectionne « Ma playlist M3U » pour saisir une URL.")
            cache.remove(url)
            fetch(url)
        }
    }

    private suspend fun fetch(url: String): List<Channel> = withContext(Dispatchers.IO) {
        cache[url] ?: M3uParser.parse(download(url))
            .distinctBy { it.url }
            .also { cache[url] = it }
    }

    private fun download(url: String): String {
        var current = url
        repeat(5) {
            val c = (URL(current).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 20_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", USER_AGENT)
            }
            try {
                val code = c.responseCode
                if (code in 300..399) {
                    current = c.getHeaderField("Location") ?: throw IOException("Redirection invalide")
                    return@repeat
                }
                if (code != 200) throw IOException("Le serveur a répondu HTTP $code")
                return c.inputStream.bufferedReader().use { it.readText() }
            } finally {
                c.disconnect()
            }
        }
        throw IOException("Trop de redirections")
    }

    // ---------- Favoris ----------
    fun favorites(): List<Channel> = runCatching {
        val arr = JSONArray(prefs.getString(KEY_FAVS, "[]"))
        (0 until arr.length()).map { Channel.fromJson(arr.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    fun favoriteUrls(): Set<String> = favorites().map { it.url }.toSet()

    fun toggleFavorite(ch: Channel) {
        val list = favorites().toMutableList()
        if (!list.removeAll { it.url == ch.url }) list.add(ch)
        prefs.edit().putString(KEY_FAVS, JSONArray(list.map { it.toJson() }).toString()).apply()
    }

    companion object {
        const val BASE = "https://iptv-org.github.io/iptv"
        const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 12; Google TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
        private const val KEY_CUSTOM = "custom_url"
        private const val KEY_FAVS = "favorites"
    }
}
