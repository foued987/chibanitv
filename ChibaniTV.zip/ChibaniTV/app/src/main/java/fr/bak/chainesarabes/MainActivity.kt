package fr.bak.chainesarabes

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.ui.graphics.Color
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.darkColorScheme

class MainActivity : ComponentActivity() {
    private val vm: HomeViewModel by viewModels()

    @OptIn(ExperimentalTvMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFF2E8CF),
                    onPrimary = Color(0xFF0E4D3A),
                    surface = Color(0xFF16201C),
                    background = Color(0xFF0B1512),
                )
            ) {
                HomeScreen(vm) { list, index ->
                    PlaybackQueue.channels = list
                    PlaybackQueue.index = index
                    startActivity(Intent(this, PlayerActivity::class.java))
                }
            }
        }
    }
}
