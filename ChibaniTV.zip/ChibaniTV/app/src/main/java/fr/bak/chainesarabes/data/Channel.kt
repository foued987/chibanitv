package fr.bak.chainesarabes.data

import org.json.JSONObject

data class Channel(
    val name: String,
    val url: String,
    val logo: String? = null,
    val group: String? = null,
    val userAgent: String? = null,
    val referrer: String? = null,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("name", name).put("url", url)
        .put("logo", logo).put("group", group)
        .put("ua", userAgent).put("ref", referrer)

    companion object {
        fun fromJson(o: JSONObject) = Channel(
            name = o.optString("name"),
            url = o.optString("url"),
            logo = o.optString("logo").ifEmpty { null },
            group = o.optString("group").ifEmpty { null },
            userAgent = o.optString("ua").ifEmpty { null },
            referrer = o.optString("ref").ifEmpty { null },
        )
    }
}
