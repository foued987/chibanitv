package fr.bak.chainesarabes.data

sealed class Source(val id: String, val label: String, val emoji: String) {
    data class Country(val code: String, val name: String) : Source("c_$code", name, flagOf(code))
    data object AllArabic : Source("ara", "Toutes (langue arabe)", "🌐")
    data object Favorites : Source("fav", "Mes favoris", "⭐")
    data object Custom : Source("custom", "Ma playlist M3U", "📂")
}

private fun flagOf(code: String): String =
    code.uppercase().map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")

object Sources {
    val countries = listOf(
        "dz" to "Algérie", "ma" to "Maroc", "tn" to "Tunisie", "ly" to "Libye",
        "mr" to "Mauritanie", "eg" to "Égypte", "sd" to "Soudan",
        "sa" to "Arabie saoudite", "ae" to "Émirats arabes unis", "qa" to "Qatar",
        "kw" to "Koweït", "bh" to "Bahreïn", "om" to "Oman", "ye" to "Yémen",
        "iq" to "Irak", "sy" to "Syrie", "lb" to "Liban", "jo" to "Jordanie",
        "ps" to "Palestine", "so" to "Somalie", "dj" to "Djibouti", "km" to "Comores",
    ).map { (code, name) -> Source.Country(code, name) }

    val all: List<Source> =
        listOf(Source.Favorites, Source.AllArabic) + countries + Source.Custom
}
