package fr.bak.chainesarabes

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import fr.bak.chainesarabes.data.Channel
import fr.bak.chainesarabes.data.ChannelRepository
import fr.bak.chainesarabes.data.Source
import fr.bak.chainesarabes.data.Sources
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HomeState(
    val selected: Source,
    val loading: Boolean = false,
    val channels: List<Channel> = emptyList(),
    val error: String? = null,
    val favoriteUrls: Set<String> = emptySet(),
)

class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = ChannelRepository(app)
    private val _state = MutableStateFlow(
        HomeState(selected = Sources.countries.first(), favoriteUrls = repo.favoriteUrls())
    )
    val state: StateFlow<HomeState> = _state
    private var job: Job? = null

    val customUrl: String? get() = repo.customUrl

    init { select(Sources.countries.first()) }

    fun select(source: Source) {
        job?.cancel()
        _state.update { it.copy(selected = source, loading = true, error = null, channels = emptyList()) }
        job = viewModelScope.launch {
            try {
                val list = repo.load(source)
                _state.update { it.copy(loading = false, channels = list) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update {
                    it.copy(loading = false, error = e.message ?: "Impossible de charger la liste. Vérifie la connexion Internet.")
                }
            }
        }
    }

    fun toggleFavorite(ch: Channel) {
        repo.toggleFavorite(ch)
        _state.update { it.copy(favoriteUrls = repo.favoriteUrls()) }
        if (_state.value.selected == Source.Favorites) select(Source.Favorites)
    }

    fun setCustomUrl(url: String) {
        repo.customUrl = url
        select(Source.Custom)
    }
}
