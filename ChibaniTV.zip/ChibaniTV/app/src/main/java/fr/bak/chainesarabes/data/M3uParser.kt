package fr.bak.chainesarabes.data

/** Lecteur de playlists M3U / M3U8 étendues (#EXTINF, #EXTVLCOPT). */
object M3uParser {
    private val attrRegex = Regex("""([A-Za-z0-9_-]+)="([^"]*)"""")

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        var info: Map<String, String> = emptyMap()
        var name: String? = null
        var ua: String? = null
        var ref: String? = null

        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    info = attrRegex.findAll(line)
                        .associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    // Le nom est après la virgule qui suit le dernier attribut
                    val tail = line.substring(line.lastIndexOf('"').coerceAtLeast(0))
                    name = tail.substringAfter(',', "").trim()
                        .ifEmpty { info["tvg-name"] ?: "Sans nom" }
                    ua = info["http-user-agent"]
                    ref = info["http-referrer"]
                }
                line.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                    val opt = line.substringAfter(':')
                    when {
                        opt.startsWith("http-user-agent=") -> ua = opt.substringAfter('=')
                        opt.startsWith("http-referrer=") -> ref = opt.substringAfter('=')
                    }
                }
                line.isEmpty() || line.startsWith("#") -> Unit
                name != null -> {
                    out += Channel(
                        name = name,
                        url = line,
                        logo = info["tvg-logo"]?.ifBlank { null },
                        group = info["group-title"]?.ifBlank { null },
                        userAgent = ua,
                        referrer = ref,
                    )
                    info = emptyMap(); name = null; ua = null; ref = null
                }
            }
        }
        return out
    }
}
